# 888-RAT [Lifetime Activated]
A famous 888 rat for Windows, Android and Linux 3 in one. The archive is uploaded on MEGA because it is too big for GitHub. Please leave a 🌟 to this repository. 
<br>Also, I would apreciante if you donate me for coffee xd:
<br>🟡LTC: LVitePdeXwNMjipuKCs17dSG9CkKVWDtFM
<br>🟡BTC: bc1qnlk7u8uzkar2pkpzdy26k64kt7adkpwv4z8s7g
<br>🟡ETH: 0x72ff129AEEa105E207AAD311EB1Ec0F7CBacDAEF
<br>🟡USDT TRC: TSTXVoueSbzgjuAPNSxFLe1saqNTFdYdt1 

![296371499-34219472-aebb-4184-8773-1e05d12c930c](https://github.com/inheritedeu/888-RAT/assets/113015812/f0efc3dd-94a4-4f31-a5a7-57d9cb068889)
